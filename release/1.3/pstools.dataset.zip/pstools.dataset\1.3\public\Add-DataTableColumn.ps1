﻿<#PSScriptInfo
    .VERSION 1.0.0.0
    .GUID 6197517b-5bf1-4bf4-b978-09993773da76
    .FILENAME Add-DataTableColumn.ps1
    .AUTHOR Hannes Palmquist
    .AUTHOREMAIL hannes.palmquist@outlook.com
    .CREATEDDATE 2020-10-13
    .COMPANYNAME Personal
    .COPYRIGHT (c) 2020, Hannes Palmquist, All Rights Reserved
#>
function Add-DataTableColumn {
    <#
    .DESCRIPTION
        Add columns to data tables. Columns can be added before or after rows have been added.

        The command operates in two modes, single column or multiple columns mode.

        Multiple mode
        In multiple mode it is possible to provide a string array 
        of column names. This is a fast and simple way to quickly 
        populate a table with empty columns.

        Single mode
        In single mode each call adds a single column to the table.
        The difference is that when single mode is used it is 
        possible to add caption, defaultvalue and expressions.

    .PARAMETER DataTable
        Defined the DataTable that columns should be added to
    .PARAMETER Names
        Defines the names of the columns. This is used to reference the column in the datatable.
    .PARAMETER Caption
        Sets the caption of the column. This is used when creating table views.
    .PARAMETER DefaultValue
        Sets the default value of a column. When set the cell of each row will get initialized with this default value.
    .PARAMETER Expression
        Sets a expression to calculate the cell value.

        For more information about expression variables and syntax see microsoft docs
        https://docs.microsoft.com/en-us/dotnet/api/system.data.datacolumn.expression?view=net-5.0
    
    .PARAMETER AllowDBNull
        Defaults to true, if set to false column will not allow null values
    
    .EXAMPLE
        Add-DataTableColumn -DataTable $DataTable -Names 'Firstname','Lastname','Address','Email'
        
        This example demostrates the use of multiple mode to create four columns in the DataTable object.

    .EXAMPLE
        Add-DataTableColumn -DataTable $DataTable -Names 'PreferredColor' -Caption 'Preferred color' -DefaultValue 'Blue'

        This example demostrates the use of single mode to create one column with a caption and a default value.
    
    .EXAMPLE 
        Add-DataTableColumn -DataTable $DataTable -Names 'Fee' -Expression '[Price] * [Amount]'

        This example demostrates the use of single mode to create one column with an expression
    #>

    [CmdletBinding(DefaultParameterSetName='Multiple')] # Enabled advanced function support
    param(
        [Parameter(Mandatory)]
        [System.Data.DataTable]
        $DataTable,

        [Parameter(Mandatory, ParameterSetName = 'Single')]
        [Parameter(Mandatory, ParameterSetName = 'Multiple')]
        [string[]]
        $Names,

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $Caption,

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $DefaultValue = '',

        [Parameter(ParameterSetName = 'Single')]
        [string]
        $Expression,

        [Parameter(ParameterSetName = 'Single')]
        [boolean]
        $AllowDBNull = $true
    )

    PROCESS {
        switch ($PSCmdlet.ParameterSetName) {
            'Single' {
                $DataColumn = New-Object System.Data.DataColumn -ArgumentList @($Names)[0]
                $DataColumn.Caption = $Caption
                $DataColumn.DefaultValue = $DefaultValue
                $DataColumn.DataType = [Object]
                if ($Expression) {
                    $DataColumn.Expression = $Expression
                }
                $DataColumn.AllowDBNull = $AllowDBNull

                [void]$DataTable.Columns.Add($DataColumn)
            }
            'Multiple' {
                foreach ($Name in $Names) {
                    $DataColumn = New-Object System.Data.DataColumn -ArgumentList $Name
                    $DataColumn.DataType = [Object]
                    [void]$DataTable.Columns.Add($DataColumn)
                }
            }
        }
    }
}
#endregion



# SIG # Begin signature block
# MIIR2AYJKoZIhvcNAQcCoIIRyTCCEcUCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUxAlf2OqgmAihvXyTWygB1Cdp
# hSSggg0/MIIDBDCCAeygAwIBAgIQXaH43Bl75ZhMB4kpXyZ2qjANBgkqhkiG9w0B
# AQUFADAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwHhcNMjAxMDIyMDczMDU3
# WhcNMjUxMDIyMDc0MDU3WjAaMRgwFgYDVQQDDA9IYW5uZXNQYWxtcXVpc3QwggEi
# MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClDvznsRz3hBOHS8rZ5ZlNB/ac
# GrKUQyoH0Pk6JONmIBeQPLwurne3ulSwb+6cbwwgp87eSnGoq4YbAFfqTbwytKLn
# YmIoHGiCrwxZb5YU6ijOrW6Sywa+H+/uKsZqJfXFRn1vGnC5tZwa5rSngLaow1qV
# tvyRQGRGNpI02hUwtChneJJmwk2B8dtY1ECH6Ob9LFlWETcETy5T5RKSS1sRWATk
# K9EQsZ65AHbGKGkpDv8y/+g7hg3KKU+m8f3ahMscMB5tvyPr3tmPsMFpFW3kCfz0
# FRBOizw+HYZX6nnSQ+aTMyXNuIXCv4Cp+1rSGdLwnRqbY5iUQca/8VZF45iZAgMB
# AAGjRjBEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQU1v0fOEkDehQn807IU73u51uJNQ0wDQYJKoZIhvcNAQEFBQADggEBABwb
# e2Ghq71GqGwx2/GoXa/Nv4XhW2O0TT5vgn6RysorCPUKTnCYKn6wGWZpdMbndXXU
# d6ziS+EW0+cxr7ZdFCTsfBroArJ3BIFjPoRt3hYqZR154nLNRnFPKhzgpusqDpSx
# BnMd7wRrKsW3GdSOfeGyiR7/9Ye2uiFp6y4wpU/qcU+LuxS2fbyUB2XGVPPWXxxF
# bjtgrlit7czi7WTjfe4YVgxyyrJ9IsMz8fPlLPy9Pfbfacpo6/p6qINhsmv+/V1o
# 7U2XIlg2w1ABj20sZ3mn+TKS2mmxNkIdCb38rUK8UJwqHX9byi9M1MrJYFJwRNwH
# 37l4hxzeVXIaiA6vWJAwggT+MIID5qADAgECAhANQkrgvjqI/2BAIc4UAPDdMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwHhcNMjEwMTAxMDAwMDAw
# WhcNMzEwMTA2MDAwMDAwWjBIMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDIxMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwuZhhGfFivUNCKRFymNrUdc6EUK9
# CnV1TZS0DFC1JhD+HchvkWsMlucaXEjvROW/m2HNFZFiWrj/ZwucY/02aoH6Kfjd
# K3CF3gIY83htvH35x20JPb5qdofpir34hF0edsnkxnZ2OlPR0dNaNo/Go+EvGzq3
# YdZz7E5tM4p8XUUtS7FQ5kE6N1aG3JMjjfdQJehk5t3Tjy9XtYcg6w6OLNUj2vRN
# eEbjA4MxKUpcDDGKSoyIxfcwWvkUrxVfbENJCf0mI1P2jWPoGqtbsR0wwptpgrTb
# /FZUvB+hh6u+elsKIC9LCcmVp42y+tZji06lchzun3oBc/gZ1v4NSYS9AQIDAQAB
# o4IBuDCCAbQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/
# BAwwCgYIKwYBBQUHAwgwQQYDVR0gBDowODA2BglghkgBhv1sBwEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMB8GA1UdIwQYMBaAFPS2
# 4SAd/imu0uRhpbKiJbLIFzVuMB0GA1UdDgQWBBQ2RIaOpLqwZr68KC0dRDbd42p6
# vDBxBgNVHR8EajBoMDKgMKAuhixodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLXRzLmNybDAyoDCgLoYsaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L3NoYTItYXNzdXJlZC10cy5jcmwwgYUGCCsGAQUFBwEBBHkwdzAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tME8GCCsGAQUFBzAChkNodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEVGltZXN0
# YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQBIHNy16ZojvOca5yAOjmdG
# /UJyUXQKI0ejq5LSJcRwWb4UoOUngaVNFBUZB3nw0QTDhtk7vf5EAmZN7WmkD/a4
# cM9i6PVRSnh5Nnont/PnUp+Tp+1DnnvntN1BIon7h6JGA0789P63ZHdjXyNSaYOC
# +hpT7ZDMjaEXcw3082U5cEvznNZ6e9oMvD0y0BvL9WH8dQgAdryBDvjA4VzPxBFy
# 5xtkSdgimnUVQvUtMjiB2vRgorq0Uvtc4GEkJU+y38kpqHNDUdq9Y9YfW5v3LhtP
# Ex33Sg1xfpe39D+E68Hjo0mh+s6nv1bPull2YYlffqe0jmd4+TaY4cso2luHpoov
# MIIFMTCCBBmgAwIBAgIQCqEl1tYyG35B5AXaNpfCFTANBgkqhkiG9w0BAQsFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMTYwMTA3MTIwMDAwWhcNMzEwMTA3MTIwMDAwWjByMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0
# YW1waW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdAy7kvN
# j3/dqbqCmcU5VChXtiNKxA4HRTNREH3Q+X1NaH7ntqD0jbOI5Je/YyGQmL8TvFfT
# w+F+CNZqFAA49y4eO+7MpvYyWf5fZT/gm+vjRkcGGlV+Cyd+wKL1oODeIj8O/36V
# +/OjuiI+GKwR5PCZA207hXwJ0+5dyJoLVOOoCXFr4M8iEA91z3FyTgqt30A6XLdR
# 4aF5FMZNJCMwXbzsPGBqrC8HzP3w6kfZiFBe/WZuVmEnKYmEUeaC50ZQ/ZQqLKfk
# dT66mA+Ef58xFNat1fJky3seBdCEGXIX8RcG7z3N1k3vBkL9olMqT4UdxB08r8/a
# rBD13ays6Vb/kwIDAQABo4IBzjCCAcowHQYDVR0OBBYEFPS24SAd/imu0uRhpbKi
# JbLIFzVuMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2hjRo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3JsMDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1
# cmVkSURSb290Q0EuY3JsMFAGA1UdIARJMEcwOAYKYIZIAYb9bAACBDAqMCgGCCsG
# AQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAQEAcZUS6VGHVmnN793afKpjerN4zwY3QITvS4S/
# ys8DAv3Fp8MOIEIsr3fzKx8MIVoqtwU0HWqumfgnoma/Capg33akOpMP+LLR2HwZ
# YuhegiUexLoceywh4tZbLBQ1QwRostt1AuByx5jWPGTlH0gQGF+JOGFNYkYkh2OM
# kVIsrymJ5Xgf1gsUpYDXEkdws3XVk4WTfraSZ/tTYYmo9WuWwPRYaQ18yAGxuSh1
# t5ljhSKMYcp5lH5Z/IwP42+1ASa2bKXuh1Eh5Fhgm7oMLSttosR+u8QlK0cCCHxJ
# rhO24XxCQijGGFbPQTS2Zl22dHv1VjMiLyI2skuiSpXY9aaOUjGCBAMwggP/AgEB
# MC4wGjEYMBYGA1UEAwwPSGFubmVzUGFsbXF1aXN0AhBdofjcGXvlmEwHiSlfJnaq
# MAkGBSsOAwIaBQCgeDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MCMGCSqGSIb3DQEJBDEWBBRwx+vo8d2XEZA67N0qTt+ZXLg7uDANBgkqhkiG9w0B
# AQEFAASCAQBWFHbD1qDTN1s6ceViLv7Q3184UHk6FhZieG+HkMKkkmwv88EJsaHy
# n0stR8DQp5HJT49D7wY71InB6Vx4Ue1I12zBQ+WI6bYyAnJ8DFsD2Jvx8TobE80F
# 94uQ+4IagyflNsU8i8WB+/xnbfKRZwn21PXGW2k1lCx6UwI4p7RRloDa88HWsNn+
# DEHOy1LGBs84ukJMF6bAPhBdyEyWM7+HNYtrcTtYoXxBvuV24dgzT3HkesryIDAw
# JU99DpMN1UVM7zrEJM6bNOPjoqP3jQwcYwTKoxxFZArci2ACGr2TjkPeuphLOIGo
# mO6W4XWAvpk1hn4U2J5c03imh08+0G/7oYICMDCCAiwGCSqGSIb3DQEJBjGCAh0w
# ggIZAgEBMIGGMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNI
# QTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0ECEA1CSuC+Ooj/YEAhzhQA8N0w
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yMTAzMjIyMjQ3MTVaMC8GCSqGSIb3DQEJBDEiBCADZLR6JgOu
# E4MKyTOhN3LybzSMckXjH0d4RlIOq3aKEDANBgkqhkiG9w0BAQEFAASCAQATPkSQ
# fAUc0crQe0fp0HFn4rug11n+SoUesoXv3LM2OgD+u4ueoIDR8FgPERDu4F8wU1/V
# aDKU0ABiZSm9ErwkfGrRsW/N1VC2nzmohRu9aXpnoSZ4JLIhYE4Pqqacto5cc6ui
# QcAZLHH5ih3hMNg48Ss+UQCCt8dos0JsLNWzo2hRBBmwDaLlkAFFoicTj/APhi8F
# XhRju0lp1SeSZpZgg6qWxvYkeNzOzPIZ+CoHI/fCEYZXIErNH7+Wo/6j3C0JugC8
# TlewWzFemhbdJ+XVdPzGCm8gzeMKaExF6NxRaPzc4aTiMXUinE70c3oLpVNzN9eP
# QOaiEF7yYJmCZvhZ
# SIG # End signature block
