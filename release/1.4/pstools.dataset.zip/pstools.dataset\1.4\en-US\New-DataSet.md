---
external help file: pstools.dataset-help.xml
Module Name: pstools.dataset
online version:
schema: 2.0.0
---

# New-DataSet

## SYNOPSIS

## SYNTAX

```
New-DataSet [<CommonParameters>]
```

## DESCRIPTION
Creates a new dataset

## EXAMPLES

### EXAMPLE 1
```
$DataSet = New-DataSet
```

This example demonstrates how to initialize a new data set object.

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
